package com.home.mps.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.home.mps.exception.MpsException;
import com.home.mps.model.MpsModel;
import com.home.mps.service.MpsService;
import com.home.mps.service.MpsServiceImpl;

public class MpsMain {
	static Scanner scanner = null;
	static MpsService mpsService = new MpsServiceImpl();
public static void main(String[] args) {
	String loopControl = "Y";
	while(loopControl.equalsIgnoreCase("y")) {
		scanner = new Scanner(System.in);
		try {
			System.out.println("Enter your choice \n1.Insert\n2.Exit");
			int choice = scanner.nextInt();
			scanner.nextLine();
			switch(choice) {
			case 1 : 
				System.out.println("Enter customer name:");
				String customerName = scanner.nextLine();
				System.out.println("Enter email:");
				String email = scanner.nextLine();
				System.out.println("Enter mobile number");
				String mobileNumber = scanner.nextLine();
				System.out.println("Enter mobile quantity");
				int mobileQnty = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter mobile name");
				String mobileName = scanner.nextLine();
				try {
					MpsModel model = new MpsModel(customerName, email, mobileNumber, mobileQnty, mobileName);
					boolean check = mpsService.validateFields(model);
					if(check==true) {
						int id= mpsService.insertValues(model);
						System.out.println("1 customer inserted with id: "+id);
					}
				}catch(MpsException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2 : System.exit(0);
			break;
			default : System.out.println("EEEEEEEEEEErrrrrrrrrorrrrrrrrrrr");
			break;
			}
			
		} catch (InputMismatchException e) {
			// TODO: handle exception
			System.err.println("Enter digits");
		}
	}
}
}

package com.home.mps.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.home.mps.dao.MpsDaoImpl;
import com.home.mps.dao.MpsDoa;
import com.home.mps.exception.MpsException;
import com.home.mps.model.MpsModel;

public class MpsServiceImpl implements MpsService {
MpsDoa dao = new MpsDaoImpl();
	@Override
	public boolean validateFields(MpsModel model) throws MpsException {
		// TODO Auto-generated method stub
		boolean validate = true;
		List<String> list = new ArrayList<String>();
		if(validateMobileName(model.getMobileName())==false) {
			list.add("Mobile not available");
		}if(customerName(model.getCustomerName())==false) {
			list.add("Name improper");
		}if(validateEmail(model.getEmail())==false) {
			list.add("email improper");
		}if(quantity(model.getMobileQnty())==false) {
			list.add("Name improper");
		}if(list.isEmpty()==false) {
			validate = false;
			throw new MpsException(list+"");
		}
		return validate;
	}
	public boolean validateMobileName(String name)throws MpsException {
		boolean check = false;
		Map<Integer, String> map = dao.mobileNames();
		if(map.containsValue(name)) {
			check = true;
		}
		return check;
	}
	public boolean customerName(String name) {
		return Pattern.matches("[A-Z][a-zA-Z ]{4,}", name);
	}
	public boolean validateEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                "[a-zA-Z0-9_+&*-]+)*@" + 
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                "A-Z]{2,7}$"; 
		return Pattern.matches(emailRegex, email);
	}
	public boolean validatePhone(String phoneNo) {
		return Pattern.matches("[0-9]{10}",phoneNo);
	}
	public boolean quantity(int qnty) {
		if(qnty>0) {
			return true;
		}
		else {
			return false;
		}
	}
	@Override
	public int insertValues(MpsModel model) throws MpsException {
		// TODO Auto-generated method stub
		return dao.insertValues(model);
	}

}

package com.home.mps.service;

import com.home.mps.exception.MpsException;
import com.home.mps.model.MpsModel;

public interface MpsService {

	boolean validateFields(MpsModel model)throws MpsException;

	int insertValues(MpsModel model) throws MpsException;

}

package com.home.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.home.mps.exception.MpsException;
import com.home.mps.model.MpsModel;
import com.home.mps.utility.JdbcUtility;

public class MpsDaoImpl implements MpsDoa {
	Map<Integer,String> map = new HashMap<Integer, String>();
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	public Map<Integer,String> mobileNames() throws MpsException{
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement =connection.prepareStatement(QueryMapper.selectMobilesQuery);
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				int id = resultSet.getInt(1);
				String name = resultSet.getString(2);
				map.put(id,name);
			}
		}catch(SQLException e) {
			throw new MpsException(e.getMessage());
		}finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return map;
	}
	@Override
	public int insertValues(MpsModel model) throws MpsException {
		Map<String,Integer> map1 = new HashMap<String, Integer>();
		Integer id=0;
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.selectMobilePriceQuery);
			ResultSet resultSet= preparedStatement.executeQuery();
			while(resultSet.next()) {
				map1.put(resultSet.getString(1),resultSet.getInt(2));
			}
			if(map1.containsKey(model.getMobileName())) {
				model.setMobileQnty(map1.get(model.getMobileName())- model.getMobileQnty());
			}
			preparedStatement = connection.prepareStatement(QueryMapper.insertpurchasedetails);
			preparedStatement.setString(1, model.getCustomerName());
			preparedStatement.setString(2, model.getEmail());
			preparedStatement.setString(3, model.getPhoneNo());
			Set<Integer> set = map.keySet();
			for(int i : set) {
				if(map.get(i).equals(model.getMobileName())) {
					System.out.println(i);
					preparedStatement.setInt(4, i);
					break;
				}
			}
			id= preparedStatement.executeUpdate();
			resultSet=((connection.prepareStatement(QueryMapper.generatedid)).executeQuery());
			resultSet.next();
			id = resultSet.getInt(1);
			connection.commit();
		} catch (SQLException e) {
			// TODO: handle exception
		throw new MpsException("Problem while getting mobiles"+e.getMessage());
		}finally {
		try {
			preparedStatement.close();
			connection.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
		
	}
return id;
}

}
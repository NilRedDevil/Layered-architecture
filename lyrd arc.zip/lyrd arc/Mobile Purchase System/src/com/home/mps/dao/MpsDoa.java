package com.home.mps.dao;

import java.util.Map;

import com.home.mps.exception.MpsException;
import com.home.mps.model.MpsModel;

public interface MpsDoa {
	public Map<Integer,String> mobileNames() throws MpsException;

	public int insertValues(MpsModel model)throws MpsException;

}

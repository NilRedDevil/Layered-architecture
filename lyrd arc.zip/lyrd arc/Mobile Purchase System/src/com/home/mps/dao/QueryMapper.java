package com.home.mps.dao;

public interface QueryMapper {
	String selectMobilesQuery = "select mobileid,name from mobiles";
	String selectMobilePriceQuery = "select name,quantity from mobiles";
	String insertpurchasedetails = "insert into purchasedetails values (mob_seq.nextval,?,?,?,sysdate,?)";
	String generatedid = "select mob_seq.currval from dual";
	

}

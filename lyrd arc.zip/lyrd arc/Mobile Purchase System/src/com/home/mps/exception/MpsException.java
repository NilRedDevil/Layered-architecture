package com.home.mps.exception;

public class MpsException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2153367768616138817L;

	public MpsException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}

package com.home.mps.model;

public class MpsModel {
private int purchaseId;
private String customerName;
private String email;
private String phoneNo;
private int mobileQnty;
private String mobileName;
private int mobileId;
public MpsModel(int purchaseId, String customerName, String email, String phoneNo, int mobileQnty, String mobileName,int mobileId) {
	super();
	this.purchaseId = purchaseId;
	this.customerName = customerName;
	this.email = email;
	this.phoneNo = phoneNo;
	this.mobileQnty = mobileQnty;
	this.mobileName = mobileName;
	this.mobileId = mobileId;
}
public MpsModel(String customerName, String email, String phoneNo, int mobileQnty, String mobileName) {
	super();
	this.customerName = customerName;
	this.email = email;
	this.phoneNo = phoneNo;
	this.mobileQnty = mobileQnty;
	this.mobileName = mobileName;
}
public int getPurchaseId() {
	return purchaseId;
}
public void setPurchaseId(int purchaseId) {
	this.purchaseId = purchaseId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public int getMobileQnty() {
	return mobileQnty;
}
public void setMobileQnty(int mobileQnty) {
	this.mobileQnty = mobileQnty;
}
public String getMobileName() {
	return mobileName;
}
public void setMobileName(String mobileName) {
	this.mobileName = mobileName;
}
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}


}

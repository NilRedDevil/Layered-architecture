package com.cg.mp.dao.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mp.dao.EmployeeDaoImpl;
import com.cg.mp.exceptions.MiniException;
import com.cg.mp.model.EmployeeModel;

public class EmployeeDaoImplTest {
	EmployeeDaoImpl dao=null;
	@Before
	public void setUp() throws Exception {
		dao=new EmployeeDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testInsertEmployee() {
		EmployeeModel emp=new EmployeeModel(100004, "Sush", "Ray",LocalDate.now(),LocalDate.now() , "BU", 102, "M2","Senior", "Married", "M", 35000, "howrah");
		try {
			int result=dao.insertEmployee(emp);
			assertEquals(1, result);
		} catch (MiniException e) {
			
		}
		
	}
	@Test
	public void testInsertEmployee1() {
		EmployeeModel emp=new EmployeeModel(100005, "Sushf", "Ray",LocalDate.now(),LocalDate.now() , "BU", 102, "M2","Senior", "Married", "M", 35000, "howrah");
		try {
			int result=dao.insertEmployee(emp);
			assertEquals(0, result);
		} catch (MiniException e) {
			
		}
		
	}


	@Test
	public void testSelectALl() {
		List<EmployeeModel> list=null;
		try {
			list=dao.selectALl();
		} catch (MiniException e) {
			
		}
		assertNotNull(list);
		
	}
	@Test
	public void testSelectALl1() {
		List<EmployeeModel> list=null;
		try {
			list=dao.selectALl();
		} catch (MiniException e) {
			
		}
		assertNull(list);
		
	}

	@Test
	public void testUpdateFirstname() {
		try {
			int i=dao.updateFirstname(100004,"Suhanto");
			assertEquals(1,i);
		} catch (MiniException e) {
			
		}
	}
	@Test
	public void testUpdateFirstname1() {
		try {
			int i=dao.updateFirstname(100004,"Suhanto");
			assertEquals(2,i);
		} catch (MiniException e) {
			
		}
	}

	

}

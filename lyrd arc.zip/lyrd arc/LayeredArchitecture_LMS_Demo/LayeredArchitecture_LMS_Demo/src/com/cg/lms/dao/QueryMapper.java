package com.cg.lms.dao;

public interface QueryMapper {

	String insertQuery = "insert into book_details(book_id,book_name,author_name,cost,publish_date) values(book_sequence.nextval,?,?,?,?)";

	String selectGeneratedId = "select book_sequence.CURRVAL from dual";
}

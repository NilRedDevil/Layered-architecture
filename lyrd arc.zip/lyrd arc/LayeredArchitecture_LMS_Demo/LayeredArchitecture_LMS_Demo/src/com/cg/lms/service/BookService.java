package com.cg.lms.service;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

public interface BookService {

	boolean validateBookDetails(BookDetails details) throws LMSException;

	int addBook(BookDetails details) throws LMSException;

}

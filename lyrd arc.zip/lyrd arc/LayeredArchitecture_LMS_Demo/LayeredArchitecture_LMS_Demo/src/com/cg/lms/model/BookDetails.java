package com.cg.lms.model;

import java.io.Serializable;
import java.time.LocalDate;

public class BookDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3524825865869555715L;
	
	private Integer bookId;
	private String bookName;
	private String authorName;
	private Double cost;
	private LocalDate publishDate;

	public BookDetails() {
		// TODO Auto-generated constructor stub
	}

	public BookDetails(String bookName, String authorName, Double cost, LocalDate publishDate) {
		super();
		this.bookName = bookName;
		this.authorName = authorName;
		this.cost = cost;
		this.publishDate = publishDate;
	}

	public BookDetails(Integer bookId, String bookName, String authorName, Double cost, LocalDate publishDate) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.authorName = authorName;
		this.cost = cost;
		this.publishDate = publishDate;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public LocalDate getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(LocalDate publishDate) {
		this.publishDate = publishDate;
	}

	@Override
	public String toString() {
		return "BookDetails [bookId=" + bookId + ", bookName=" + bookName + ", authorName=" + authorName + ", cost="
				+ cost + ", publishDate=" + publishDate + "]";
	}

}

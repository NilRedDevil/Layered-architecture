package com.cg.ems.doa.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ems.doa.EmsDoaImpl;
import com.cg.ems.exceptions.EmsException;
import com.cg.ems.model.EmsModel;

public class EmsDoaImplTest {
EmsDoaImpl test = null;
	@Before
	public void setUpBeforeClass() {
		test = new EmsDoaImpl();
	}

	@After
	public void tearDownAfterClass() {
		test = null;
	}

	@Test
	public void testInsertValues() {
		
		EmsModel emsModel = new EmsModel(1000, "Sapta", "Electrical", 12000d, LocalDate.now());
		try {
			int check = test.insertValues(emsModel);
			assertEquals(0, check);
		} catch (EmsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
public void testInsertValues1() {
		
		EmsModel emsModel = new EmsModel(1000, "Sapta", "Electrical", 12000d, LocalDate.now());
		try {
			int check = test.insertValues(emsModel);
			assertNotSame(0, check);
		} catch (EmsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

package com.cg.ems.exceptions;

public class EmsException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1954454774060074742L;

	public EmsException(String message) {
		super(message);
	}

}

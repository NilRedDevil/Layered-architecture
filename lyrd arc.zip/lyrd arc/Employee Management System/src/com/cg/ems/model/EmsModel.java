package com.cg.ems.model;

import java.io.Serializable;
import java.time.LocalDate;

public class EmsModel implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer empId;
	private String empName;
	private String department;
	private Double salary;
	private LocalDate doj;
	
	public EmsModel() {
		// TODO Auto-generated constructor stub
	}

	public EmsModel(Integer empId, String empName, String department, Double salary, LocalDate doj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.department = department;
		this.salary = salary;
		this.doj = doj;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "EmsModel [empId=" + empId + ", empName=" + empName + ", department=" + department + ", salary=" + salary
				+ ", doj=" + doj + "]";
	}
	
	
	
}

package com.cg.ems.doa;

import com.cg.ems.exceptions.EmsException;
import com.cg.ems.model.EmsModel;

public interface EmsDoa {
	public int insertValues(EmsModel emsModel)throws EmsException;
}

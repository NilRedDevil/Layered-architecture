package com.cg.ems.doa;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.ems.exceptions.EmsException;
import com.cg.ems.model.EmsModel;
import com.cg.ems.utility.JdbcUtility;

public class EmsDoaImpl implements EmsDoa{
	
	static Logger logger = Logger.getLogger(EmsDoaImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	

	public int insertValues(EmsModel emsModel1) throws EmsException {
		int string=0;
		logger.info("in DAO impl class");
		logger.info("Book data is : " + emsModel1);

		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QuerryMapper.insertQuery);
			logger.info("connection established..");
			
			statement.setInt(1,emsModel1.getEmpId());
			statement.setString(2, emsModel1.getEmpName());
			statement.setString(3, emsModel1.getDepartment());
			statement.setDouble(4, emsModel1.getSalary());
			statement.setDate(5, Date.valueOf(emsModel1.getDoj()));
			
			string=statement.executeUpdate();
			logger.info("statement executed, record inserted");

			
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new EmsException("unable to close resultset object");
		}
		try {
			statement.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new EmsException("unable to close statement object");
		}

		try {
			connection.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new EmsException("unable to close connection object");
		}
		
		return string;
	}

	
}

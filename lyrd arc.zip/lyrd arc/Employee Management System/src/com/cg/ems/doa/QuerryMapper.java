package com.cg.ems.doa;

public interface QuerryMapper {
	
	String insertQuery = "insert into emp_details values(?,?,?,?,?)";

	
	
}

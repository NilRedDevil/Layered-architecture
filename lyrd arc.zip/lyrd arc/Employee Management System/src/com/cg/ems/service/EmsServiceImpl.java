package com.cg.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.ems.doa.EmsDoa;
import com.cg.ems.doa.EmsDoaImpl;
import com.cg.ems.exceptions.EmsException;
import com.cg.ems.model.EmsModel;

public class EmsServiceImpl implements EmsService {
	EmsDoa doa = new EmsDoaImpl();

	public boolean validate(EmsModel emsModel) throws EmsException {
		boolean validateFlag = true;
		List<String> list = new ArrayList<>();

		if (validateEmployeeId(emsModel.getEmpId()) == false) {
			list.add("empid no proper");
		}
		if (validateName(emsModel.getEmpName()) == false) {
			list.add("Name no proper");
		}

		if (validateDepartment(emsModel.getDepartment()) == false) {
			list.add("Enter right department");
		}

		if (validateSalary(emsModel.getSalary()) == false) {
			list.add("tui min 10000 pas re banchod");
		}

		if (list.isEmpty() == false) {
			validateFlag = false;
			throw new EmsException(list + "");
		}
		return validateFlag;
	}

	public boolean validateEmployeeId(Integer employeeId) {

		return Pattern.matches("[0-9]{4}", Integer.toString(employeeId));
	}

	public boolean validateName(String name) {

		return Pattern.matches("[A-Z][A-Za-z ]{4,14}", name);
	}

	public boolean validateDepartment(String department) {
		return Pattern.matches("[A-Z][A-Za-z]{4,14}", department);
	}

	public boolean validateSalary(double salary) {

		boolean salaryFlag = true;
		if (salary < 10000) {
			salaryFlag = false;
		}
		return salaryFlag;
	}

	public int insertValues(EmsModel emsModel) throws EmsException {
		return doa.insertValues(emsModel);
	}

}

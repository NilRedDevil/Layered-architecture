package com.cg.ems.service;

import com.cg.ems.exceptions.EmsException;
import com.cg.ems.model.EmsModel;

public interface EmsService {
	public boolean validate(EmsModel emsModel)throws EmsException;
	public int insertValues(EmsModel emsModel)throws EmsException;
}

package com.cg.ems.presentation;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.exceptions.EmsException;
import com.cg.ems.model.EmsModel;
import com.cg.ems.service.EmsService;
import com.cg.ems.service.EmsServiceImpl;

public class EmsMain {

	static Logger logger = Logger.getLogger(EmsMain.class);

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file configured..");

		EmsService service = new EmsServiceImpl();

		Scanner sc = null;

		System.out.println("*** Welcome to Employee Management System *** ");
		try {
			sc = new Scanner(System.in);
			System.out.println("Enter choice\n1.Insert\n2.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				while (true) {
					try {
						sc.nextLine();

						System.out.println("EmpID");
						int empId = sc.nextInt();
						
			
						sc.nextLine();
						System.out.println("Enter name");
						String empName = sc.nextLine();
						System.out.println("Enter department");
						String department = sc.nextLine();
						double salary = 0;
						boolean salaryFlag = false;

						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Salary:");
							try {
								salary = sc.nextDouble();
								salaryFlag = true;
							} catch (InputMismatchException e) {
								salaryFlag = false;
								System.err.println("salary should contain  only digits");
							}
						} while (!salaryFlag);

						sc.nextLine();

						String doj = "";
						boolean publishFlag = false;
						DateTimeFormatter formatter = null;
						LocalDate localDate = null;

						do {
							sc = new Scanner(System.in);
							System.out.println("Enter date of joining (dd-MM-yyyy)");
							doj = sc.nextLine();
							formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

							try {
								localDate = LocalDate.parse(doj, formatter);
								publishFlag = true;
							} catch (DateTimeException e) {
								publishFlag = false;
								System.err.println("date should be in the given format - (dd-MM-yyyy)");
							}
						} while (!publishFlag);

						EmsModel emsModel = new EmsModel(empId, empName, department, salary, localDate);
						try {
							boolean result = service.validate(emsModel);
							System.out.println("validated");
							if (result == true) {
								int msg=service.insertValues(emsModel);
								System.out.println(msg+"values inserted");
							}
							break;
						} catch (EmsException e) {
							System.out.println(e.getMessage());
						}
					} catch (InputMismatchException e) {
						System.err.println("Only numbers are allowed.");
					}
				}

				break;
			case 2:
				System.out.println("Thank u, visit again");
				System.exit(0);
				break;

			default:
				System.out.println("Give some proper input from choice.");
				break;
			}

		} catch (InputMismatchException e) {
			System.err.println("Give some proper input.");
		}
		sc.close();
	}

}

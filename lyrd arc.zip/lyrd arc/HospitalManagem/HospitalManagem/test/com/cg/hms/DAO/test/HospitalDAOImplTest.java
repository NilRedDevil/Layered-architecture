package com.cg.hms.DAO.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.hms.DAO.HospitalDAO;
import com.cg.hms.DAO.HospitalDAOImpl;
import com.cg.hms.exception.HMSException;
import com.cg.hms.model.HospitalDetails;

public class HospitalDAOImplTest {

	HospitalDAOImpl hospital;
	@Before
	public void setUp() throws Exception {
		hospital=new HospitalDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		hospital=null;
	}

	@Test
	public void hospitalTest() {
		HospitalDetails hobj=new HospitalDetails();
		hobj.setPatName("Priya");
		hobj.setPatPhno(9038548806l);
		hobj.setProblem("ENT");
		int i;
		try {
			i=hospital.insertDetails(hobj);
			assertNotNull(i);
		} catch (HMSException e) {
			System.err.println("Cant be inserted");
		}
	}
	@Test
	public void hospitalNullTest() {
		HospitalDetails hobj=new HospitalDetails();
		hobj.setPatName("Priya");
		hobj.setPatPhno(9038548806l);
		hobj.setProblem("ENT");
		int i;
		try {
			i=hospital.insertDetails(hobj);
			assertNull(i);
		} catch (HMSException e) {
			System.err.println("Cant be inserted");
		}
	}

}

package com.cg.hms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.hms.DAO.HospitalDAO;
import com.cg.hms.DAO.HospitalDAOImpl;
import com.cg.hms.exception.HMSException;
import com.cg.hms.model.HospitalDetails;

public class HospitalServiceImpl implements HospitalService{
	boolean result;
	HospitalDAO dao=new HospitalDAOImpl();

	@Override
	public boolean validateInput(HospitalDetails hospital) throws HMSException {
		List<String>  list=new ArrayList<>();
		if(validateName(hospital.getPatName())==false)
			list.add("Enter first letter capital");
		if(validatePhno(hospital.getPatPhno())==false)
			list.add("Enter 10 digit number");
		if(list.isEmpty())
			result=true;
		else
			throw new HMSException(list+"");
		
		return result;
	}

	public boolean validatePhno(Long patPhno) {
		String regex="[6|7|8|9]{1}[0-9]{9}";
		
		return Pattern.matches(regex, String.valueOf(patPhno));
	}

	public boolean validateName(String name) {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		return Pattern.matches(nameRegEx, name);
	}

	@Override
	public int insertDetails(HospitalDetails hospital) throws HMSException {
		
		return dao.insertDetails(hospital);
	}


}

package com.cg.hms.service;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.HospitalDetails;

public interface HospitalService {

	boolean validateInput(HospitalDetails hospital) throws HMSException;

	int insertDetails(HospitalDetails hospital) throws HMSException;

}

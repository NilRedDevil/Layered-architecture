package com.cg.hms.DAO;

public interface QueryMapper {
	public String insertQuery="insert into hospital values(pat_seq.nextval,?,SYSDATE,?,?,?)";
	public String genIdQuery="select pat_seq.CURRVAL from dual";
}

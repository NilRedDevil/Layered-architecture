package com.cg.hms.model;

public class HospitalDetails {
	private String patName;
	private Integer transactionId;
	private String appDate;
	private String docName;
	private String problem;
	private Long patPhno;
	
	public HospitalDetails() {
		// TODO Auto-generated constructor stub
	}

	public HospitalDetails(String patName, Integer transactionId, String appDate, String docName, String problem,
			Long patPhno) {
		super();
		this.patName = patName;
		this.transactionId = transactionId;
		this.appDate = appDate;
		this.docName = docName;
		this.problem = problem;
		this.patPhno = patPhno;
	}

	

	public HospitalDetails(String patName,  String problem, Long patPhno) {
		super();
		this.patName = patName;
		this.problem = problem;
		this.patPhno = patPhno;
	}

	public String getPatName() {
		return patName;
	}

	public void setPatName(String patName) {
		this.patName = patName;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getAppDate() {
		return appDate;
	}

	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public Long getPatPhno() {
		return patPhno;
	}

	public void setPatPhno(Long patPhno) {
		this.patPhno = patPhno;
	}

	@Override
	public String toString() {
		return "HospitalDetails [patName=" + patName + ", transactionId=" + transactionId + ", appDate=" + appDate
				+ ", docName=" + docName + ", problem=" + problem + ", patPhno=" + patPhno + "]";
	}

	
	
}

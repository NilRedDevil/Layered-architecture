package com.cg.hms.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.HospitalDetails;
import com.cg.hms.service.HospitalService;
import com.cg.hms.service.HospitalServiceImpl;

public class HospitalMain {

	static Logger logger=Logger.getLogger(HospitalMain.class);
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file configuration....");
		Scanner scanner = new Scanner(System.in);
		HospitalService service=new HospitalServiceImpl();
		int choice;
		long patPhno = 0;
		boolean choiceFlag = false, phFlag = false, billFlag = false;
		do {
			System.out.println("**********Hospital Management System**********");
			System.out.println("1.Insert");
			System.out.println("2.Exit");
			try {
				choice = scanner.nextInt();
				choiceFlag = false;
				scanner.nextLine();
				switch (choice) {
				case 1:
					System.out.println("Enter Name:");
					String patName = scanner.nextLine();

					do {
						System.out.println("Enter Phone:");
						try {
							patPhno = scanner.nextLong();
							phFlag = false;
						} catch (InputMismatchException e) {
							phFlag = true;
							scanner.nextLine();
							System.out.println("Please enter digits");
						}
					} while (phFlag);
					scanner.nextLine();
					System.out.println("Enter Problem:");
					String problem = scanner.nextLine();
					HospitalDetails hospital=new HospitalDetails(patName, problem, (long)patPhno);
					try {
						boolean result=service.validateInput(hospital);
						if(result)
						{
							int genId=service.insertDetails(hospital);
							System.out.println("Row inserted with transaction number:"+genId);
							
						}
						else
							System.out.println("Not");
					} catch (HMSException e) {
						System.err.println(e.getMessage());
					}
					
	
					break;
				case 2:

					System.out.println("Thank u, visit again");
					System.exit(0);
					
					break;

				default:
					choiceFlag = false;
					System.out.println("choice from (1-2)");
					break;
				}
			} catch (InputMismatchException e) {
				scanner.nextLine();
				choiceFlag = false;
				System.out.println("Enter digits only");
			}
		} while (!choiceFlag);
		
	scanner.close();

	}

}

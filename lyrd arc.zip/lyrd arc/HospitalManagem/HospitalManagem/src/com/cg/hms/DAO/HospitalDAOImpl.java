package com.cg.hms.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.HospitalDetails;
import com.cg.hms.utility.JdbcUtility;

public class HospitalDAOImpl implements HospitalDAO {

	Connection connection = null;
	ResultSet resultSet = null;
	PreparedStatement statement = null;
	int result = 1;
	/**
	 * method: insertDetails(Object) return type: integer author:Capgemini
	 * date:19-02-2019
	 */

	static Logger logger = Logger.getLogger(HospitalDAOImpl.class);

	@Override
	public int insertDetails(HospitalDetails hospital) throws HMSException {
		Map<String, String> map = new HashMap<>();
		map.put("High Fever", "Dr. Bhowmik");
		map.put("Oncology", "Dr. Das");
		map.put("ENT", "Dr. Chakraborty");
		String docName = "NOT KNOWN";
		logger.info("Map created....");
		connection = JdbcUtility.getConnection();

		Set<String> set = map.keySet();
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			statement.setString(1, hospital.getPatName());
			for (String name : set) {

				if (name.equalsIgnoreCase(hospital.getProblem())) {
					logger.info("Doctor Matched Dr. Name:" + docName);
					System.out.println(map.get(name));
					System.out.println(hospital.getProblem());
					docName = map.get(name);
					break;
				} 
			}
			statement.setString(2, docName);
			statement.setString(3, hospital.getProblem());
			statement.setLong(4, hospital.getPatPhno());
			
			statement.executeUpdate();

			connection.commit();

			statement = connection.prepareStatement(QueryMapper.genIdQuery);

			resultSet = statement.executeQuery();
			resultSet.next();
			result = resultSet.getInt(1);
			logger.info("Values inserted for generated id:" + result);

		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				logger.error("Problem in rollback");
				System.out.println(e1.getMessage());
			}
			logger.error(e.getMessage());
			throw new HMSException("Problem in forming statement" + e);
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new HMSException("Problem in connection");

			}
			/*try {
				resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new HMSException("Problem in resultset");

			}*/
			try {
				statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new HMSException("Problem in statement");

			}
		}
		return result;
	}

}

package com.cg.hms.DAO;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.HospitalDetails;

public interface HospitalDAO {

	int insertDetails(HospitalDetails hospital) throws HMSException;

}
